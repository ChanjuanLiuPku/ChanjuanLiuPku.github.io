---
permalink: /
title: ""
excerpt: ""
author_profile: true
redirect_from: 
  - /about/
  - /about.html
---



<span class='anchor' id='about-me'></span>

{% include_relative includes/intro.md %}

{% include_relative includes/news.md %}

{% include_relative includes/pubs.md %}

{% include_relative includes/honers.md %}

{% include_relative includes/others.md %}

{% include_relative includes/projects.md %}
