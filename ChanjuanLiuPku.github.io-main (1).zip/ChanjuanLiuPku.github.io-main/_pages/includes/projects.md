# Projects
- 1X6 Project, 2023-2024
- General Program of National Natural Science Foundation of China, 2021-2025
- Youth Fund of the National Natural Science Foundation of China, 2018-2020
- Young Elite Scientists Sponsorship Program by CAST, 2018-2020
- Dalian High level Talent Innovation Support Plan
